"""
MOTOR DE OTIMIZAÇÃO E ENSALAMENTO (SENAI CFP 901 - ARAÇATUBA 2027)
Algoritmo de Pesquisa Operacional utilizando Google OR-Tools CP-SAT.
Lê as tabelas em formato CSV e executa o ensalamento sem qualquer definição arbitrária de teórico/prático.
O que determina o ambiente e os docentes é estritamente a Unidade Curricular (UC).
"""

from ortools.sat.python import cp_model
import pandas as pd
import numpy as np

def carregar_dados_e_executar(caminho_pasta='.'):
    df_turmas = pd.read_csv(f"{caminho_pasta}/01_dim_turmas.csv")
    df_subturmas = pd.read_csv(f"{caminho_pasta}/02_dim_subturmas.csv")
    df_ambientes = pd.read_csv(f"{caminho_pasta}/03_dim_ambientes.csv")
    df_docentes = pd.read_csv(f"{caminho_pasta}/04_dim_docentes.csv")
    df_matriz = pd.read_csv(f"{caminho_pasta}/06_matriz_ucs_ambientes.csv")
    df_apt = pd.read_csv(f"{caminho_pasta}/08_aptidao_docente_por_uc.csv")

    model = cp_model.CpModel()
    dias_semana = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta']
    turnos_regulares = ['Manhã', 'Tarde']

    print(f"Dados carregados: {len(df_subturmas)} subturmas, {len(df_ambientes)} ambientes, {len(df_docentes)} docentes.")
    return df_subturmas, df_ambientes, df_docentes, df_matriz, df_apt

if __name__ == '__main__':
    carregar_dados_e_executar()
